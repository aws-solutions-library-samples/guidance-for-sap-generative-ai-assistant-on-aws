"""DEPRECATED: Kept for backwards compatibility."""
from langchain.utilities import Requests, RequestsWrapper, TextRequestsWrapper

__all__ = [
    "Requests",
    "RequestsWrapper",
    "TextRequestsWrapper",
]
